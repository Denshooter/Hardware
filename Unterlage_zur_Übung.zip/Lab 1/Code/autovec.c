#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define SIZE (1L << 16)

double vec1[SIZE];
double vec2[SIZE];

void test(double *a, double *b) {
    for (int i = 0; i < SIZE; i++) {
        a[i] += b[i];
    }
}

int main(int argc, const char *argv[])
{
    for (int i = 0; i < SIZE; i++) {
        vec1[i] = i;
        vec2[i] = i;
    }
    test(vec1, vec2);
    return 0;
}
